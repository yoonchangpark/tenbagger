from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.company import router as company_router
from app.core.database import check_db

app = FastAPI(
    title="텐배거 헌터 API",
    description="한국 주식 장기투자 분석 시스템",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(company_router)


@app.get("/health")
def health():
    db_ok = check_db()
    return {
        "status": "ok",
        "db": "connected" if db_ok else "disconnected",
    }


@app.get("/")
def root():
    return {"message": "텐배거 헌터 API", "docs": "/docs"}

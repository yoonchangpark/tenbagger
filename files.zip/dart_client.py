"""
DART OpenAPI 클라이언트
공식 문서: https://opendart.fss.or.kr/guide/main.do
"""
import httpx
import asyncio
from typing import Optional
from app.core.config import settings

DART_BASE = "https://opendart.fss.or.kr/api"


async def _get(path: str, params: dict) -> dict:
    params["crtfc_key"] = settings.dart_api_key
    async with httpx.AsyncClient(timeout=30.0) as client:
        r = await client.get(f"{DART_BASE}/{path}", params=params)
        r.raise_for_status()
        return r.json()


async def get_corp_code(stock_code: str) -> Optional[str]:
    """종목코드 → DART 고유번호(corp_code) 변환"""
    import zipfile, io, xml.etree.ElementTree as ET

    async with httpx.AsyncClient(timeout=30.0) as client:
        params = {"crtfc_key": settings.dart_api_key}
        r = await client.get(f"{DART_BASE}/corpCode.xml", params=params)
        r.raise_for_status()

    zf = zipfile.ZipFile(io.BytesIO(r.content))
    xml_data = zf.read("CORPCODE.xml")
    root = ET.fromstring(xml_data)

    for item in root.findall("list"):
        code = item.findtext("stock_code", "").strip()
        if code == stock_code:
            return item.findtext("corp_code", "").strip()
    return None


async def get_financial_statements(corp_code: str, year: int, report_type: str = "11011") -> dict:
    """
    단일 재무제표 조회 (연결 우선, 없으면 별도)
    report_type: 11011=사업보고서, 11012=반기, 11013=1분기, 11014=3분기
    """
    params = {
        "corp_code": corp_code,
        "bsns_year": str(year),
        "reprt_code": report_type,
        "fs_div": "CFS",  # 연결재무제표
    }
    data = await _get("fnlttSinglAcntAll.json", params)

    # 연결재무제표 없으면 별도재무제표로 재시도
    if data.get("status") != "000" or not data.get("list"):
        params["fs_div"] = "OFS"
        data = await _get("fnlttSinglAcntAll.json", params)

    return data


async def get_dividend_info(corp_code: str, year: int) -> dict:
    """배당 정보 조회"""
    params = {
        "corp_code": corp_code,
        "bsns_year": str(year),
        "reprt_code": "11011",
    }
    return await _get("alotMatter.json", params)


def parse_amount(value_str: str) -> Optional[int]:
    """DART 금액 문자열 → 정수 (단위: 원)"""
    if not value_str or value_str.strip() in ("", "-", "N/A"):
        return None
    try:
        cleaned = value_str.replace(",", "").strip()
        # DART는 기본 원 단위
        return int(float(cleaned))
    except (ValueError, TypeError):
        return None


def extract_account(items: list, account_names: list) -> Optional[int]:
    """재무제표 항목 리스트에서 특정 계정 추출"""
    for name in account_names:
        for item in items:
            if item.get("account_nm", "").strip() == name:
                val = parse_amount(item.get("thstrm_amount", ""))
                if val is not None:
                    return val
    return None


async def fetch_yearly_financials(corp_code: str, ticker: str, years: int = 8) -> list[dict]:
    """
    최근 N년치 재무데이터 수집
    반환: [{year, revenue, operating_profit, net_income, ...}, ...]
    """
    import datetime
    current_year = datetime.date.today().year
    results = []

    for year in range(current_year - 1, current_year - years - 1, -1):
        try:
            data = await get_financial_statements(corp_code, year)
            items = data.get("list", [])
            if not items:
                continue

            row = {"year": year, "ticker": ticker}

            # ── 손익계산서 ────────────────────────────────────────────────────
            row["revenue"] = extract_account(items, [
                "매출액", "수익(매출액)", "영업수익", "매출"
            ])
            row["operating_profit"] = extract_account(items, [
                "영업이익", "영업이익(손실)"
            ])
            row["net_income"] = extract_account(items, [
                "당기순이익", "당기순이익(손실)", "분기순이익"
            ])

            # ── 재무상태표 ────────────────────────────────────────────────────
            row["total_assets"]  = extract_account(items, ["자산총계"])
            row["total_equity"]  = extract_account(items, ["자본총계"])
            row["total_debt"]    = extract_account(items, ["부채총계"])
            row["cash"]          = extract_account(items, ["현금및현금성자산"])
            row["current_assets"]= extract_account(items, ["유동자산"])
            row["current_liab"]  = extract_account(items, ["유동부채"])

            # ── 현금흐름표 ────────────────────────────────────────────────────
            row["cfo"]   = extract_account(items, ["영업활동 현금흐름", "영업활동으로 인한 현금흐름"])
            row["capex"] = extract_account(items, [
                "유형자산의 취득", "유형자산 취득", "유형자산취득"
            ])
            if row["cfo"] and row["capex"]:
                row["fcf"] = row["cfo"] - abs(row["capex"])

            results.append(row)
            await asyncio.sleep(0.3)  # DART rate limit 방지

        except Exception as e:
            print(f"[DART] {ticker} {year}년 수집 실패: {e}")
            continue

    return results
